from setuptools import setup

setup(
    name='DebtsBot',
    version='0.0.1',
    packages=[''],
    url='https://github.com/mtaranovsky/DebtsBot',
    license='',
    author='Trush',
    author_email='trushboyandriy@gmail.com',
    description=''
)
